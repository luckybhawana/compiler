package wci.frontend;

/**
 * <h1>TokenType</h1>
 *
 * <p>The token type interface.</p>
 *
 * <p>Copyright (c) 2009 by Ronald Mak</p>
 * <p>For instructional purposes only.  No warranties.</p>
 */
public interface TokenType
{
}
